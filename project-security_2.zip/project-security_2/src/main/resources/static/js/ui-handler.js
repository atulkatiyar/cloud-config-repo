// UI Handler for managing DOM updates
const UIHandler = {
    renderCacheEntry(entry) {
        const entryDiv = document.createElement('div');
        entryDiv.className = 'cache-entry card';
        entryDiv.innerHTML = `
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="card-subtitle mb-2 text-muted">ID: ${entry.id}</h6>
                        <p class="card-text">Data: ${entry.data}</p>
                        <p class="card-text">Expires in: ${entry.expiryMinutes} minutes</p>
                        <p class="card-text">Created at: ${new Date(entry.createdAt).toLocaleString()}</p>
                    </div>
                    <button class="btn btn-danger btn-sm delete-btn" data-id="${entry.id}">
                        Delete
                    </button>
                </div>
            </div>
        `;
        return entryDiv;
    },

    updateCacheEntriesList(entries) {
        const entriesDiv = document.getElementById('cacheEntries');
        entriesDiv.innerHTML = '';
        
        if (entries.length === 0) {
            entriesDiv.innerHTML = '<p class="text-muted">No cached entries found.</p>';
            return;
        }

        entries.forEach(entry => {
            entriesDiv.appendChild(this.renderCacheEntry(entry));
        });
    },

    showMessage(message, type = 'success') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.role = 'alert';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        const container = document.querySelector('.container');
        container.insertBefore(alertDiv, container.firstChild);
        
        setTimeout(() => alertDiv.remove(), 3000);
    }
};