// Cache Service for handling API calls
const CacheService = {
    async saveData(data) {
        const response = await fetch('/api/cache/data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) {
            throw new Error('Failed to save data');
        }
    },

    async getAllData() {
        const response = await fetch('/api/cache/data');
        if (!response.ok) {
            throw new Error('Failed to fetch data');
        }
        return response.json();
    },

    async deleteEntry(id) {
        const response = await fetch(`/api/cache/data/${id}`, {
            method: 'DELETE'
        });
        if (!response.ok) {
            throw new Error('Failed to delete entry');
        }
    },

    async deleteAllEntries() {
        const response = await fetch('/api/cache/data', {
            method: 'DELETE'
        });
        if (!response.ok) {
            throw new Error('Failed to delete all entries');
        }
    }
};