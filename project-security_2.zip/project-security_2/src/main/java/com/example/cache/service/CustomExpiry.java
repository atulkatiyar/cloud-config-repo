package com.example.cache.service;

import com.github.benmanes.caffeine.cache.Expiry;
import com.example.cache.model.CacheEntry;
import java.util.concurrent.TimeUnit;

public class CustomExpiry implements Expiry<String, CacheEntry> {
    @Override
    public long expireAfterCreate(String key, CacheEntry value, long currentTime) {
        // Convert minutes to nanoseconds for Caffeine
        return TimeUnit.MINUTES.toNanos(value.getExpiryMinutes());
    }

    @Override
    public long expireAfterUpdate(String key, CacheEntry value, long currentTime, long currentDuration) {
        // On update, reset expiry to the entry's configured expiry time
        return TimeUnit.MINUTES.toNanos(value.getExpiryMinutes());
    }

    @Override
    public long expireAfterRead(String key, CacheEntry value, long currentTime, long currentDuration) {
        // Don't extend expiry on read
        return currentDuration;
    }
}