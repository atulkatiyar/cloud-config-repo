package com.example.cache.security;

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;

public interface AuthenticationProvider {
    void configure(AuthenticationManagerBuilder auth) throws Exception;
}