package com.example.cache.security;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@Profile("memory")
@RequiredArgsConstructor
public class InMemoryAuthenticationProvider implements AuthenticationProvider {
    
    private final PasswordEncoder passwordEncoder;
    
    @Override
    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication()
            .withUser("user1")
            .password(passwordEncoder.encode("password1"))
            .roles("USER")
            .and()
            .withUser("user2")
            .password(passwordEncoder.encode("password2"))
            .roles("USER");
    }
}