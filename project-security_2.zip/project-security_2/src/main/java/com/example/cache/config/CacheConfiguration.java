package com.example.cache.config;

import com.example.cache.model.CacheEntry;
import com.example.cache.service.CustomExpiry;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class CacheConfiguration {
    
    @Bean
    public Cache<String, CacheEntry> cacheStorage() {
        return Caffeine.newBuilder()
                .expireAfter(new CustomExpiry())
                .maximumSize(1000)
                .removalListener((key, value, cause) -> 
                    log.info("Cache entry removed: key={}, cause={}", key, cause))
                .build();
    }
}