package com.lseg.ipps.solutions.shared.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public record ConfigurationParametersResponse(@JsonProperty("logging_levels") List<ConfigurationParameterResponse> configurationParameterResponseList) {
}
