package com.lseg.ipps.solutions.shared.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lseg.ipps.solutions.shared.model.CacheEntry;
import com.lseg.ipps.solutions.shared.request.ConfigurationParameterResponse;
import com.lseg.ipps.solutions.shared.service.cache.CacheEntryManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.ssm.SsmClient;
import software.amazon.awssdk.services.ssm.model.GetParametersByPathRequest;
import software.amazon.awssdk.services.ssm.model.GetParametersByPathResponse;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ConfigurationService {

    private final Logger log = LoggerFactory.getLogger(ConfigurationService.class);

    public static final String ROOT_LEVEL_KEY = "root";

    public static final String LOGGING_LEVELS = "packageLogLevels";

    public static final String LOG_CONFIG_HAS_BEEN_UPDATED_SUCCESSFULLY = "Log config has been updated successfully";

    private final CacheEntryManager cacheEntryManager;

    public ConfigurationService(CacheEntryManager cacheEntryManager) {
        this.cacheEntryManager = cacheEntryManager;
    }

    /**
     * @return @{@link ResponseEntity}
     */
    public String fetchAndPersistUpdatedLogLevel() {

        List<ConfigurationParameterResponse> parameterValues = new ArrayList<>();
        String nextToken = null;
        try (SsmClient ssmClient = SsmClient.builder().region(Region.EU_WEST_1)
                .credentialsProvider(ProfileCredentialsProvider.builder().profileName("saml").build())
                .build()) {
            do {
                GetParametersByPathRequest getParametersByPathRequest = GetParametersByPathRequest.builder()
                        .path("/log-config")
                        .recursive(true)   // Fetch all nested parameters
                        .withDecryption(true) // If SecureString, decrypt values
                        .maxResults(10)    // Fetch in batches (optional)
                        .nextToken(nextToken)
                        .build();

                GetParametersByPathResponse response = ssmClient.getParametersByPath(getParametersByPathRequest);
                ObjectMapper objectMapper = new ObjectMapper();
                List<ConfigurationParameterResponse> configurationParameterResponseList = response.parameters()
                        .stream()
                        .map(parameter -> {
                            try {
                                return objectMapper.readValue(parameter.value(), ConfigurationParameterResponse.class);
                            } catch (JsonProcessingException e) {
                                throw new RuntimeException(e);
                            }
                        }).toList();
                parameterValues.addAll(configurationParameterResponseList);
                nextToken = response.nextToken();
            } while (nextToken != null);
            persistDataInMemory(parameterValues);
        } catch (Exception e) {
           log.error("Exception in fetchAndPersistUpdatedLogLevel " + e.getMessage());
           return "failed";
        }
        return "success";
    }

    private void persistDataInMemory(List<ConfigurationParameterResponse> parameterList) {
        parameterList = parameterList.stream()
                .filter(configurationParameterResponse -> isParameterExpired(configurationParameterResponse.expiryTimestamp()))
                .collect(Collectors.toList());

        Optional<ConfigurationParameterResponse> rootLevel = parameterList.stream()
                .filter(parameter -> "ROOT".equalsIgnoreCase(parameter.packageName()))
                .findFirst();
        Map<String, ConfigurationParameterResponse> data = new HashMap<>();

        long localDateTime = LocalDateTime.now().atZone(ZoneId.of("UTC")).toInstant().getEpochSecond();
        data.put(ROOT_LEVEL_KEY, rootLevel.orElseGet(() ->
                new ConfigurationParameterResponse(ROOT_LEVEL_KEY, "WARN", "0", String.valueOf(localDateTime))));
        parameterList.stream()
                .filter(parameter -> !ROOT_LEVEL_KEY.equalsIgnoreCase(parameter.packageName()))
                .forEach(configurationParameterResponse -> data.put(configurationParameterResponse.packageName(), configurationParameterResponse));
        CacheEntry entry = new CacheEntry(LOGGING_LEVELS, data);
        cacheEntryManager.saveEntry(entry);
    }

    public boolean isParameterExpired(String expiryTimestamp) {
        try {
            long expiryTimeInSeconds = Long.parseLong(expiryTimestamp);
            LocalDateTime expiryDateTime = LocalDateTime.ofInstant(
                    Instant.ofEpochSecond(expiryTimeInSeconds),
                    ZoneId.of("UTC")
            );
            LocalDateTime currentDateTime = LocalDateTime.now().atZone(ZoneId.of("UTC")).toLocalDateTime();
            return currentDateTime.isAfter(expiryDateTime);

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid expiry timestamp format: " + expiryTimestamp, e);
        }
    }

}
