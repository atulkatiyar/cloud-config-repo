package com.lseg.ipps.solutions.shared.components;

import com.lseg.ipps.solutions.shared.service.ConfigurationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;


@Component
public class LogLevelStartupRunner {

    private final Logger log = LoggerFactory.getLogger(LogLevelStartupRunner.class);
    private final ConfigurationService configurationService;

    @Autowired
    public LogLevelStartupRunner(ConfigurationService configurationService) {
        this.configurationService = configurationService;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() throws Exception {
        String message = configurationService.fetchAndPersistUpdatedLogLevel();
        log.info(" Status fetchAndPersistUpdatedLogLevel :: " + message);
    }
}
