package com.lseg.ipps.solutions.shared.controller;

import com.lseg.ipps.solutions.shared.model.CacheEntry;
import com.lseg.ipps.solutions.shared.request.ConfigurationParameterResponse;
import com.lseg.ipps.solutions.shared.request.ConfigurationParametersResponse;
import com.lseg.ipps.solutions.shared.service.ConfigurationService;
import com.lseg.ipps.solutions.shared.service.cache.CacheEntryManager;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class LogConfigController {

    private static final Logger logger = LogManager.getLogger(LogConfigController.class);
    public static final String ROOT_LEVEL_KEY = "root";
    public static final String WARN = "WARN";
    public static final String PACKAGE_LOG_LEVELS = "packageLogLevels";
    private final FreeMarkerConfigurationFactoryBean freemarkerConfig;


    private final ConfigurationService configurationService;

    private final CacheEntryManager cacheEntryManager;

    public LogConfigController(FreeMarkerConfigurationFactoryBean freemarkerConfig,
                               ConfigurationService configurationService, CacheEntryManager cacheEntryManager) {
        this.freemarkerConfig = freemarkerConfig;
        this.configurationService = configurationService;
        this.cacheEntryManager = cacheEntryManager;
    }


    @GetMapping("/log4j2.json")
    public ResponseEntity<ConfigurationParametersResponse> getLog4jData() {
        Map<String, Object> data = new HashMap<>();
        data.put(ROOT_LEVEL_KEY, WARN);
        Optional<CacheEntry> logConfigData = cacheEntryManager.getAllCacheEntries()
                .stream()
                .filter(cacheEntry -> cacheEntry.key().equalsIgnoreCase(PACKAGE_LOG_LEVELS)).findFirst();
        if (logConfigData.isPresent() && !logConfigData.get().data().isEmpty()) {
            List<ConfigurationParameterResponse> consolidatedMap = logConfigData
                    .stream()
                    .map(CacheEntry::data)
                    .flatMap(map -> map.entrySet().stream())
                    .filter(stringConfigurationParameterResponseEntry ->
                            configurationService.isParameterExpired(stringConfigurationParameterResponseEntry.getValue().expiryTimestamp()))
                    .map(Map.Entry::getValue)
                    .collect(Collectors.toList());
            return ResponseEntity.ok(new ConfigurationParametersResponse(consolidatedMap));
        }
        return ResponseEntity.ok(
                new ConfigurationParametersResponse(List.of(
                        new ConfigurationParameterResponse(ROOT_LEVEL_KEY, WARN, "", ""))));
    }

    @GetMapping("/log4j2.xml")
    public ResponseEntity<String> generateLog4jXml() throws IOException {

        List<CacheEntry> logConfigData = cacheEntryManager.getAllCacheEntries();
        if (logConfigData.isEmpty()) {
            return ResponseEntity.ok(processTemplateAndGenerateXmlContent(populateDefaultMap()));
        }
        Map<String, Object> consolidatedMap = new HashMap<>();
        Map<String, Object> packageLogLevelMap = logConfigData
                .stream()
                .map(CacheEntry::data)
                .flatMap(map -> map.entrySet().stream())
                .filter(stringConfigurationParameterResponseEntry -> !ROOT_LEVEL_KEY.equalsIgnoreCase(stringConfigurationParameterResponseEntry.getKey()) &&
                        configurationService.isParameterExpired(stringConfigurationParameterResponseEntry.getValue().expiryTimestamp()))
                .map(Map.Entry::getValue).collect(Collectors.toMap(ConfigurationParameterResponse::packageName, ConfigurationParameterResponse::logLevel));
        consolidatedMap.put(PACKAGE_LOG_LEVELS, packageLogLevelMap);
        consolidatedMap.put(ROOT_LEVEL_KEY, logConfigData.stream().map(CacheEntry::data)
                .flatMap(map -> map.entrySet().stream())
                .filter(stringConfigurationParameterResponseEntry -> ROOT_LEVEL_KEY.equalsIgnoreCase(stringConfigurationParameterResponseEntry.getKey()) &&
                        configurationService.isParameterExpired(stringConfigurationParameterResponseEntry.getValue().expiryTimestamp()))
                        .map(Map.Entry::getValue).map(ConfigurationParameterResponse::logLevel).findFirst().orElse(WARN));
            return ResponseEntity.ok(processTemplateAndGenerateXmlContent(consolidatedMap));
    }

    private Map<String, Object> populateDefaultMap() {
        Map<String, Object> defaultLogLevelMap = new HashMap<>();
        defaultLogLevelMap.put(ROOT_LEVEL_KEY, WARN);
        return defaultLogLevelMap;
    }



    private String processTemplateAndGenerateXmlContent(Map<String, Object> defaultLogLevelMap) throws IOException {
        StringWriter writer = new StringWriter();
        Template template;
        try {
            template = freemarkerConfig.createConfiguration().getTemplate("log4j_template.ftl");
            template.process(defaultLogLevelMap, writer);
            return writer.toString();
        } catch (IOException | TemplateException e) {
            throw new RuntimeException(e);
        } finally {
            writer.close();
        }
    }

    @DeleteMapping("/log4j2.xml")
    public ResponseEntity<Object> clearExistingLogging() {
        cacheEntryManager.deleteAllEntries();
        logger.info("Cache cleared for all the users ");
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @PostMapping("/refresh-log-level")
    public ResponseEntity<String> refreshLogLevel() {
        return ResponseEntity.ok(configurationService.fetchAndPersistUpdatedLogLevel());
    }

}
