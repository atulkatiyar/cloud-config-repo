package com.lseg.ipps.solutions.shared.config;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.lseg.ipps.solutions.shared.model.CacheEntry;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CacheConfig {

    @Value("${app.cache.config.maxSize}")
    private int maxSize;

    @Bean
    public Cache<String, CacheEntry> cacheStorage() {
        return Caffeine.newBuilder()
                //.expireAfter(new CustomExpiry())
                .maximumSize(maxSize)
                .build();
    }
}
