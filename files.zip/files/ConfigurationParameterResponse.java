package com.lseg.ipps.solutions.shared.request;

import com.fasterxml.jackson.annotation.JsonProperty;


public record ConfigurationParameterResponse(
        @JsonProperty("package") String packageName,
        @JsonProperty("log_level") String logLevel,
        @JsonProperty("expiry_time") String expiryTime,
        @JsonProperty("expiry_timestamp") String expiryTimestamp
) {
}
