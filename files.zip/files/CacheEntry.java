package com.lseg.ipps.solutions.shared.model;


import com.lseg.ipps.solutions.shared.request.ConfigurationParameterResponse;

import java.util.Map;

public record CacheEntry(String key, Map<String, ConfigurationParameterResponse> data) {
}
