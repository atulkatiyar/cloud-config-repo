package com.lseg.ipps.solutions.shared.service.cache;


import com.github.benmanes.caffeine.cache.Cache;
import com.lseg.ipps.solutions.shared.model.CacheEntry;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class CacheEntryManager {

    private static final Logger logger = LogManager.getLogger(CacheEntryManager.class);
    private final Cache<String, CacheEntry> storage;

    public CacheEntryManager(Cache<String, CacheEntry> storage) {
        this.storage = storage;
    }

    /**
     * Method to save data in cache for the user
     * @param entry @{@link CacheEntry}
     */
    public void saveEntry(CacheEntry entry) {
        try {
            storage.put(entry.key(), entry);
            logger.info("Saved cache entry: key={}, expiryMinutes={}", entry.key());
        } catch (Exception e) {
            logger.error("error while saving cache entry: key={}, exception={}", entry.key(), e.getMessage());
        }
    }

    /**
     * Method to fetch entry from cache by username and userId
     * @param cacheKey @{@link String}
     * @return @{@link CacheEntry}
     */
    public Optional<CacheEntry> getEntry(String cacheKey) {
        CacheEntry entry = storage.getIfPresent(cacheKey);
        if (entry == null) {
            logger.debug("Cache miss: key={}", cacheKey);
            return Optional.empty();
        }
        logger.debug("Cache hit: key={}", cacheKey);
        return Optional.of(entry);
    }

    /**
     * Method to fetch all entries from cache
     * @return @{@link List}
     */
    public List<CacheEntry> getAllCacheEntries() {
        List<CacheEntry> allEntries = new ArrayList<>();
        storage.asMap().forEach((key, value) -> allEntries.add(value));
        logger.debug("Retrieved {} entries", allEntries.size());
        return allEntries;
    }

    /**
     * Method to delete entry from cache by username and id
     * @param cacheKey @{@link String}
     * @return @boolean
     */
    public boolean deleteEntry(String cacheKey) {
        CacheEntry entry = storage.getIfPresent(cacheKey);
        if (entry != null && entry.key().equals(cacheKey)) {
            storage.invalidate(cacheKey);
            logger.info("Deleted cache entry: key={}", cacheKey);
            return true;
        }
        logger.debug("Cache entry not found for deletion: key={}", cacheKey);
        return false;
    }


    /**
     * Method to delete all entries from cache
     */
    public void deleteAllEntries() {
        List<String> keysToDelete = new ArrayList<>();
        storage.asMap().forEach((key, value) -> {
            keysToDelete.add(key);
        });
        keysToDelete.forEach(storage::invalidate);
        logger.info("Deleted {} entries for all user ", keysToDelete.size());
    }
}