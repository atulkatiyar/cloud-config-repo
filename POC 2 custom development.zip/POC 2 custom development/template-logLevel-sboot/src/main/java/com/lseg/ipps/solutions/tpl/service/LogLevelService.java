package com.lseg.ipps.solutions.tpl.service;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class LogLevelService {

    private static final Logger logger = LogManager.getLogger(LogLevelService.class);
    public void testLoggingLevel() {
        logger.debug("[LogLevelService] Debug message from LogExample");
        logger.info("[LogLevelService] Info message from LogExample");
        logger.warn("[LogLevelService]  Warning message from LogExample");
        logger.error("[LogLevelService]  Error message from LogExample");
    }
}
