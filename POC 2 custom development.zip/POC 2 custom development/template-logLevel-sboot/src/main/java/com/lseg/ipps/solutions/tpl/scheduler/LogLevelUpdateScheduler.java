package com.lseg.ipps.solutions.tpl.scheduler;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Component
public class LogLevelUpdateScheduler {

    private static final String LOG4J_XML_URL = "http://localhost:8086/generate-log4j-xml";
    private static final String LOG4J_XML_PATH = "/Users/komalsharma/Downloads/template-logLevel-sboot/target/classes/log4j2.xml";

    @Autowired
    private RestTemplate restTemplate;
    private static final Logger logger = LogManager.getLogger(LogLevelUpdateScheduler.class);


    @Value("${log.level.changes.duration}")
    private long schedulerDurationMillis;


    /**
     * Method to schedule the log level changes
     */
    @Scheduled(fixedRateString = "${log.level.changes.duration}")
    public void downloadLog4jXmlPeriodically() {
        try {
            ResponseEntity<byte[]> response = null;
            /*HttpHeaders headers = new HttpHeaders();
            headers.add("Accept", "application/xml");
            HttpEntity<Void> entity = new HttpEntity<>(headers);
            ResponseEntity<byte[]> response = restTemplate.exchange(
                    LOG4J_XML_URL, HttpMethod.POST, entity, byte[].class);

            if (response.getStatusCode() == HttpStatus.OK) {

                File file = new File(LOG4J_XML_PATH);
                file.getParentFile().mkdirs();
                try (FileOutputStream fileOutputStream = new FileOutputStream(file)) {
                    fileOutputStream.write(response.getBody());
                }
            }*/
            System.out.println("Log4j XML generated and saved:   " + response);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }


    public void downloadLog4jXml() {
        try {
            String xmlContent = restTemplate.postForObject(LOG4J_XML_URL, null, String.class);
            if (xmlContent != null) {
                saveLog4jXmlToFile(xmlContent);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to download log4j2.xml.");
        }
    }

    // Save the downloaded log4j2.xml content to the container's filesystem
    private void saveLog4jXmlToFile(String xmlContent) {
        try (FileOutputStream fos = new FileOutputStream(LOG4J_XML_PATH)) {
            fos.write(xmlContent.getBytes());
            fos.flush();
            System.out.println("log4j2.xml saved to: " + LOG4J_XML_PATH);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
