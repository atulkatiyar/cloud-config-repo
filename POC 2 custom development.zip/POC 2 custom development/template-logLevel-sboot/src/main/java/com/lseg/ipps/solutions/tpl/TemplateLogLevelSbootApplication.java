package com.lseg.ipps.solutions.tpl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class TemplateLogLevelSbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemplateLogLevelSbootApplication.class, args);
	}

}
