package com.lseg.ipps.solutions.tpl.cache;

import java.util.concurrent.*;
import java.util.function.Function;


public class Log4JCache {

    private final ConcurrentMap<String, Object> cache = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, Long> timestamps = new ConcurrentHashMap<>();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    private final TimeUnit  timeUnit;

    private static Log4JCache instance;

    public static Log4JCache getInstance(long expirationDuration) {
        if (instance == null) {
            synchronized (Log4JCache.class) {
                if (instance == null) {
                    instance = new Log4JCache(TimeUnit.SECONDS, expirationDuration);
                }
            }
        }
        return instance;
    }

    private Log4JCache( TimeUnit timeUnit, long expirationDuration) {
        this.timeUnit = timeUnit;
        try {
            scheduler.scheduleAtFixedRate(this::removeExpiredEntries, 0, expirationDuration, timeUnit);
        }  catch (Exception e){
            System.out.println("");
        }
    }

    public Object get(String key) {
        return cache.get(key);
    }

    public Object put(String key, Object value) {
        timestamps.put(key, System.nanoTime());
        return cache.put(key, value);
    }

    public Object putIfAbsent(String key, Object value) {
        timestamps.putIfAbsent(key, System.nanoTime());
        return cache.putIfAbsent(key, value);
    }

    public Object computeIfAbsent(String key, Function<? super String, ? extends Object> mappingFunction) {
        timestamps.putIfAbsent(key, System.nanoTime());
        return cache.computeIfAbsent(key, k -> {
            Object value = mappingFunction.apply(k);
            timestamps.put(k, System.nanoTime());
            return value;
        });
    }

    public boolean remove(String key, Object value) {
        timestamps.remove(key);
        return cache.remove(key, value);
    }

    private void removeExpiredEntries() {
        long expirationDuration = 90;
        long expirationThreshold = System.nanoTime() - timeUnit.toNanos(expirationDuration);
        for (String key : timestamps.keySet()) {
            if (timestamps.get(key) < expirationThreshold) {
                timestamps.remove(key);
                cache.remove(key);
            }
        }
    }

    public void shutdown() {
        scheduler.shutdown();
    }
}
