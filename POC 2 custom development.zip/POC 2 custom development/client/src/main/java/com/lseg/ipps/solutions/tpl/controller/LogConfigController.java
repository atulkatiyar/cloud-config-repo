package com.lseg.ipps.solutions.tpl.controller;

import com.lseg.ipps.solutions.tpl.cache.Log4JCache;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
public class LogConfigController {

    private final FreeMarkerConfigurationFactoryBean freemarkerConfig;

    public LogConfigController(FreeMarkerConfigurationFactoryBean freemarkerConfig) {
        this.freemarkerConfig = freemarkerConfig;
    }

    @GetMapping("/")
    public String showDashboard() {
        return "dashboard";
    }

    @PostMapping("/generate-log4j-config")
    public String generateLog4j(
            @RequestParam String rootLevel,
            @RequestParam(required = false) String filePath,
            @RequestParam(required = false) String packageName,
            @RequestParam(required = false) String packageLevel,
            @RequestParam Map<String, String> timer,
            Model model) {
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("rootLevel", rootLevel);

            if (filePath != null && !filePath.isEmpty())     {
                Map<String, String> fileAppender = new HashMap<>();
                fileAppender.put("path", filePath);
                data.put("fileAppender", fileAppender);
            }
            Map<String, String> filteredPackageLogLevels = new HashMap<>();
            filteredPackageLogLevels.put(packageName, packageLevel);
            data.put("packageLogLevels", filteredPackageLogLevels);

            long cacheExpirationTime = Long.parseLong(timer.get("timer"));
            if(cacheExpirationTime == 0) {
                cacheExpirationTime = 90L;
            }
            Log4JCache log4JCache = Log4JCache.getInstance(cacheExpirationTime);
            log4JCache.put("log4j-config", data);

            model.addAttribute("message", "log4j.xml has been generated successfully!");
        } catch (Exception e) {
            model.addAttribute("error", "Error generating log4j.xml: " + e.getMessage());
        }
        return "dashboard";
    }

    @PostMapping("/generate-log4j-xml")
    public ResponseEntity<FileSystemResource> generateLog4jXml() {

        Map<String, Object> data;
        Log4JCache log4JCache = Log4JCache.getInstance(0);
        Object obj = log4JCache.get("log4j-config");
        if(obj instanceof HashMap && ((Map<String, Object>)obj).size() > 0) {
            data = (Map<String, Object>) obj;
            File log4jXmlFile = new File("log4j2.xml");
            Template template;
            try {
                template = freemarkerConfig.createConfiguration().getTemplate("log4j_template.ftl");
                FileWriter writer = new FileWriter(log4jXmlFile);
                template.process(data, writer);
                writer.close();
            } catch (IOException | TemplateException e) {
                throw new RuntimeException(e);
            }

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + log4jXmlFile.getName())
                    .contentType(MediaType.APPLICATION_XML)
                    .contentLength(log4jXmlFile.length())
                    .body(new FileSystemResource(log4jXmlFile));

        } else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

}
