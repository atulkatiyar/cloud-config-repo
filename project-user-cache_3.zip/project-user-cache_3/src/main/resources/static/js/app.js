// Main application logic
document.addEventListener('DOMContentLoaded', () => {
    loadCachedData();
    setupEventListeners();
    startAutoRefresh();
});

async function loadCachedData() {
    try {
        const entries = await CacheService.getAllData();
        UIHandler.updateCacheEntriesList(entries);
    } catch (error) {
        UIHandler.showMessage('Error loading cached data', 'danger');
        console.error('Failed to load cached data:', error);
    }
}

function setupEventListeners() {
    setupFormSubmission();
    setupDeleteHandlers();
}

function setupFormSubmission() {
    document.getElementById('dataForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const data = {
            id: document.getElementById('id').value,
            data: document.getElementById('data').value,
            expiryMinutes: parseInt(document.getElementById('expiryMinutes').value)
        };

        try {
            await CacheService.saveData(data);
            document.getElementById('dataForm').reset();
            UIHandler.showMessage('Data saved successfully');
            loadCachedData();
        } catch (error) {
            UIHandler.showMessage('Error saving data', 'danger');
            console.error('Failed to save data:', error);
        }
    });
}

function setupDeleteHandlers() {
    // Delete single entry
    document.getElementById('cacheEntries').addEventListener('click', async (e) => {
        if (e.target.classList.contains('delete-btn')) {
            const id = e.target.dataset.id;
            if (await confirmDelete('Are you sure you want to delete this entry?')) {
                try {
                    await CacheService.deleteEntry(id);
                    UIHandler.showMessage('Entry deleted successfully');
                    loadCachedData();
                } catch (error) {
                    UIHandler.showMessage('Error deleting entry', 'danger');
                    console.error('Failed to delete entry:', error);
                }
            }
        }
    });

    // Delete all entries
    document.getElementById('deleteAllBtn').addEventListener('click', async () => {
        if (await confirmDelete('Are you sure you want to delete all your cached entries?')) {
            try {
                await CacheService.deleteAllEntries();
                UIHandler.showMessage('All entries deleted successfully');
                loadCachedData();
            } catch (error) {
                UIHandler.showMessage('Error deleting entries', 'danger');
                console.error('Failed to delete all entries:', error);
            }
        }
    });
}

function startAutoRefresh() {
    // Refresh cached data every 30 seconds
    setInterval(loadCachedData, 30000);
}

async function confirmDelete(message) {
    return window.confirm(message);
}