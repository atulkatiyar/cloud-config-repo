package com.example.cache.model;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CacheEntry {
    private String id;
    private String data;
    private int expiryMinutes;
    private LocalDateTime createdAt;
    private String username;
}