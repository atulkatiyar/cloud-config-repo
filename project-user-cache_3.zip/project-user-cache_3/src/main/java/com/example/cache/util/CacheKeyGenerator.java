package com.example.cache.util;

import org.springframework.stereotype.Component;
import lombok.experimental.UtilityClass;

@UtilityClass
public class CacheKeyGenerator {
    private static final String SEPARATOR = "_";

    public static String generateKey(String username, String id) {
        if (username == null || username.isEmpty()) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("ID cannot be null or empty");
        }
        return username + SEPARATOR + id;
    }
}