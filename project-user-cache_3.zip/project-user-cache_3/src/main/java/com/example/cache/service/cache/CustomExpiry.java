package com.example.cache.service.cache;

import com.github.benmanes.caffeine.cache.Expiry;
import com.example.cache.model.CacheEntry;
import java.util.concurrent.TimeUnit;

public class CustomExpiry implements Expiry<String, CacheEntry> {
    @Override
    public long expireAfterCreate(String key, CacheEntry value, long currentTime) {
        return TimeUnit.MINUTES.toNanos(value.getExpiryMinutes());
    }

    @Override
    public long expireAfterUpdate(String key, CacheEntry value, long currentTime, long currentDuration) {
        return TimeUnit.MINUTES.toNanos(value.getExpiryMinutes());
    }

    @Override
    public long expireAfterRead(String key, CacheEntry value, long currentTime, long currentDuration) {
        return currentDuration;
    }
}