package com.example.cache.service.cache;

import com.example.cache.model.CacheEntry;
import com.github.benmanes.caffeine.cache.Cache;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class CacheEntryManager {
    private final Cache<String, CacheEntry> storage;
    private final CacheKeyManager keyManager;

    public void saveEntry(CacheEntry entry) {
        String cacheKey = keyManager.generateKey(entry.getUsername(), entry.getId());
        System.out.println(" storage " + storage.hashCode());
        storage.put(cacheKey, entry);
        log.info("Saved cache entry: key={}, expiryMinutes={}", cacheKey, entry.getExpiryMinutes());
    }

    public Optional<CacheEntry> getEntry(String username, String id) {
        String cacheKey = keyManager.generateKey(username, id);
        System.out.println(" storage " + storage.hashCode());
        CacheEntry entry = storage.getIfPresent(cacheKey);
        
        if (entry == null) {
            log.debug("Cache miss: key={}", cacheKey);
            return Optional.empty();
        }
        
        log.debug("Cache hit: key={}", cacheKey);
        return Optional.of(entry);
    }

    public List<CacheEntry> getUserEntries(String username) {
        List<CacheEntry> userEntries = new ArrayList<>();
        System.out.println(" storage " + storage.hashCode());
        storage.asMap().forEach((key, value) -> {
            if (keyManager.extractUsername(key).equals(username)) {
                userEntries.add(value);
            }
        });
        log.debug("Retrieved {} entries for user: {}", userEntries.size(), username);
        return userEntries;
    }

    public boolean deleteEntry(String username, String id) {
        String cacheKey = keyManager.generateKey(username, id);
        System.out.println(" storage " + storage.hashCode());
        CacheEntry entry = storage.getIfPresent(cacheKey);
        
        if (entry != null && entry.getUsername().equals(username)) {
            storage.invalidate(cacheKey);
            log.info("Deleted cache entry: key={}", cacheKey);
            return true;
        }
        
        log.debug("Cache entry not found for deletion: key={}", cacheKey);
        return false;
    }

    public void deleteUserEntries(String username) {
        List<String> keysToDelete = new ArrayList<>();
        System.out.println(" storage " + storage.hashCode());
        storage.asMap().forEach((key, value) -> {
            if (keyManager.extractUsername(key).equals(username)) {
                keysToDelete.add(key);
            }
        });
        
        keysToDelete.forEach(storage::invalidate);
        log.info("Deleted {} entries for user: {}", keysToDelete.size(), username);
    }
}