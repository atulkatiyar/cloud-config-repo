package com.example.cache.service;

import com.example.cache.model.CacheEntry;
import com.example.cache.service.cache.CacheEntryManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CacheStorageService {
    private final CacheEntryManager cacheEntryManager;

    public void saveData(String username, String id, String data, int expiryMinutes) {
        CacheEntry entry = CacheEntry.builder()
                .id(id)
                .data(data)
                .expiryMinutes(expiryMinutes)
                .createdAt(LocalDateTime.now())
                .username(username)
                .build();
        
        cacheEntryManager.saveEntry(entry);
    }

    public Optional<CacheEntry> getData(String username, String id) {
        return cacheEntryManager.getEntry(username, id);
    }

    public List<CacheEntry> getAllUserEntries(String username) {
        return cacheEntryManager.getUserEntries(username);
    }

    public boolean deleteEntry(String username, String id) {
        return cacheEntryManager.deleteEntry(username, id);
    }

    public void deleteAllUserEntries(String username) {
        cacheEntryManager.deleteUserEntries(username);
    }
}