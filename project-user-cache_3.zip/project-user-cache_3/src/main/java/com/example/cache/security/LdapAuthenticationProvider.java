package com.example.cache.security;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.stereotype.Component;

@Component
@Profile("ldap")
@RequiredArgsConstructor
public class LdapAuthenticationProvider implements AuthenticationProvider {
    
    @Override
    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.ldapAuthentication()
            .userDnPatterns("uid={0},ou=people")
            .groupSearchBase("ou=groups")
            .contextSource()
            .url("ldap://localhost:8389/dc=example,dc=com")
            .and()
            .passwordCompare()
            .passwordAttribute("userPassword");
    }
}