package com.example.cache.controller;

import com.example.cache.dto.DataSaveRequest;
import com.example.cache.model.CacheEntry;
import com.example.cache.service.CacheStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cache")
@RequiredArgsConstructor
public class CacheController {
    private final CacheStorageService cacheStorageService;

    @PostMapping("/data")
    public ResponseEntity<Void> saveData(@RequestBody DataSaveRequest request, Authentication authentication) {
        cacheStorageService.saveData(
            authentication.getName(),
            request.getId(),
            request.getData(),
            request.getExpiryMinutes()
        );
        return ResponseEntity.ok().build();
    }

    @GetMapping("/data/{id}")
    public ResponseEntity<CacheEntry> getData(@PathVariable String id, Authentication authentication) {
        return cacheStorageService.getData(authentication.getName(), id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/data")
    public ResponseEntity<List<CacheEntry>> getAllUserData(Authentication authentication) {
        List<CacheEntry> entries = cacheStorageService.getAllUserEntries(authentication.getName());
        return ResponseEntity.ok(entries);
    }

    @DeleteMapping("/data/{id}")
    public ResponseEntity<Void> deleteData(@PathVariable String id, Authentication authentication) {
        boolean deleted = cacheStorageService.deleteEntry(authentication.getName(), id);
        return deleted ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/data")
    public ResponseEntity<Void> deleteAllUserData(Authentication authentication) {
        cacheStorageService.deleteAllUserEntries(authentication.getName());
        return ResponseEntity.ok().build();
    }
}