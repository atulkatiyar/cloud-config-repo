package com.example.cache.dto;

import lombok.Data;

@Data
public class DataSaveRequest {
    private String id;
    private String data;
    private int expiryMinutes;
}