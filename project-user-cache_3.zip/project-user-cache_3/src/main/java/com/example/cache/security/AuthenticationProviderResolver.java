package com.example.cache.security;

import lombok.RequiredArgsConstructor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AuthenticationProviderResolver {
    
    private final AuthenticationProvider authProvider;
    
    public void configureAuthentication(AuthenticationManagerBuilder auth) throws Exception {
        authProvider.configure(auth);
    }
}