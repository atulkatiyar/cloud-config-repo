package com.example.cache.service;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class UserAwareCacheService {

    @Cacheable(value = "userCache", key = "#root.target.getCurrentUserKey() + '_' + #id")
    public String getCachedData(String id) {
        // Simulate expensive operation
        return "Data for ID: " + id;
    }

    public String getCurrentUserKey() {
        return SecurityContextHolder.getContext().getAuthentication().getName();
    }
}