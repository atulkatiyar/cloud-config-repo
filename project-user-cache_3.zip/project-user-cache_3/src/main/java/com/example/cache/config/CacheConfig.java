package com.example.cache.config;

import com.example.cache.model.CacheEntry;
import com.example.cache.service.CustomExpiry;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CacheConfig {
    
    @Bean
    public Cache<String, CacheEntry> cacheStorage() {
        return Caffeine.newBuilder()
                .expireAfter(new CustomExpiry())
                .maximumSize(1000)
                .build();
    }
}