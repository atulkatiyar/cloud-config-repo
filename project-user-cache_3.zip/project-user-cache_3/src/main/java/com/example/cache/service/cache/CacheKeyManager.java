package com.example.cache.service.cache;

import org.springframework.stereotype.Component;

@Component
public class CacheKeyManager {
    private static final String SEPARATOR = "::";

    public String generateKey(String username, String id) {
        validateInput(username, "Username");
        validateInput(id, "ID");
        return username + SEPARATOR + id;
    }

    public String extractUsername(String key) {
        return key.split(SEPARATOR)[0];
    }

    private void validateInput(String value, String fieldName) {
        if (value == null || value.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be null or empty");
        }
    }
}