package com.example.cache.security;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.context.ApplicationContext;

@Component
@RequiredArgsConstructor
public class AuthenticationProviderFactory {
    
    private final ApplicationContext context;
    
    public AuthenticationProvider getProvider() {
        String[] activeProfiles = context.getEnvironment().getActiveProfiles();
        String profile = activeProfiles.length > 0 ? activeProfiles[0] : "default";
        
        switch (profile) {
            case "memory":
                return context.getBean("inMemoryAuthenticationProvider", AuthenticationProvider.class);
            case "jdbc":
                return context.getBean("jdbcAuthenticationProvider", AuthenticationProvider.class);
            case "ldap":
                return context.getBean("ldapAuthenticationProvider", AuthenticationProvider.class);
            default:
                return context.getBean("defaultAuthenticationProvider", AuthenticationProvider.class);
        }
    }
}