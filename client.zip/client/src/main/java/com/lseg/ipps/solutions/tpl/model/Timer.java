package com.lseg.ipps.solutions.tpl.model;

public class Timer {
    private long remainingTime;
    private long startTime;
    private long endTime;

    public Timer(long remainingTime, long startTime) {
        this.remainingTime = remainingTime;
        this.startTime = startTime;
    }

    public long getRemainingTime() {
        return remainingTime;
    }

    public void setRemainingTime(long remainingTime) {
        this.remainingTime = remainingTime;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }
}
