package com.lseg.ipps.solutions.tpl.service;

import com.lseg.ipps.solutions.tpl.cache.Log4JCache;
import com.lseg.ipps.solutions.tpl.model.Timer;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Service
public class TimerService {


    public long startOrGetTimer(String userId, long time, Log4JCache log4JCache) {

        long cacheExpirationTime = time;
        if(cacheExpirationTime == 0) {
            cacheExpirationTime = 90L;
        } else{
            cacheExpirationTime = cacheExpirationTime * 60 * 1000;
        }
        Timer timer = new Timer(cacheExpirationTime, System.currentTimeMillis());
        if (timer.getEndTime() < System.currentTimeMillis()) {
            timer.setRemainingTime(cacheExpirationTime);
            timer.setStartTime(System.currentTimeMillis());
            timer.setEndTime(System.currentTimeMillis() + cacheExpirationTime);
        }

        log4JCache.put("admin_timer", timer);
        return getRemainingTime(userId);
    }

    public long getRemainingTime(String userId) {
        Log4JCache log4JCache = Log4JCache.getInstance(TimeUnit.SECONDS, 0);
        Timer timer = (Timer) log4JCache.get("admin_timer");
        if (timer == null) {
            return 0;
        }
        long remaining = timer.getEndTime() - System.currentTimeMillis();
        return Math.max(0, remaining);
    }
}
