package com.lseg.ipps.solutions.tpl.controller;

import com.lseg.ipps.solutions.tpl.cache.Log4JCache;
import com.lseg.ipps.solutions.tpl.model.TimerResponse;
import com.lseg.ipps.solutions.tpl.service.TimerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;


@Controller
public class TimerController {

    @Autowired
    private TimerService timerService;


    @GetMapping("/get-remaining-time")
    public ResponseEntity<TimerResponse> getRemainingTime(@RequestParam String userId) {
        long remainingTime = timerService.getRemainingTime(userId);
        Log4JCache log4JCache = Log4JCache.getInstance(TimeUnit.SECONDS, 0);
        return ResponseEntity.ok(new TimerResponse(remainingTime, (Map<String, Object>)log4JCache.get("log4j-config")));
    }
}
