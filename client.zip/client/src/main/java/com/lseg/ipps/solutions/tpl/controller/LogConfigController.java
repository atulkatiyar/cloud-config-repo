package com.lseg.ipps.solutions.tpl.controller;

import com.lseg.ipps.solutions.tpl.cache.Log4JCache;
import com.lseg.ipps.solutions.tpl.model.TimerResponse;
import com.lseg.ipps.solutions.tpl.service.TimerService;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Controller()
public class LogConfigController {

    private final FreeMarkerConfigurationFactoryBean freemarkerConfig;

    @Autowired
    private TimerService timerService;

    public LogConfigController(FreeMarkerConfigurationFactoryBean freemarkerConfig) {
        this.freemarkerConfig = freemarkerConfig;
    }

    @GetMapping("/index2")
    public String showDashboard() {
        return "index2";
    }

    @PostMapping("/generate-log4j-config")
    public ResponseEntity<TimerResponse>  generateLog4j(
            @RequestParam String rootLevel,
            @RequestParam(required = false) String filePath,
            @RequestParam(required = false) String packageName,
            @RequestParam(required = false) String packageLevel,
            @RequestParam Map<String, String> timer,
            Model model) {
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("rootLevel", rootLevel);
            if (filePath != null && !filePath.isEmpty())     {
                Map<String, String> fileAppender = new HashMap<>();
                fileAppender.put("path", filePath);
                data.put("fileAppender", fileAppender);
            }
            Map<String, String> filteredPackageLogLevels = new HashMap<>();
            filteredPackageLogLevels.put(packageName, packageLevel);
            data.put("packageLogLevels", filteredPackageLogLevels);

            long cacheExpirationTime = Long.parseLong(timer.get("timer"));

            Log4JCache log4JCache = Log4JCache.getInstance(TimeUnit.SECONDS, cacheExpirationTime);
            long remainingTime = timerService.startOrGetTimer("admin", cacheExpirationTime, log4JCache);
            log4JCache.put("admin", remainingTime);
            log4JCache.put("log4j-config", data);
            log4JCache.put("configGenerated", true);
            model.addAttribute("userId", "admin");
            model.addAttribute("remainingTime", cacheExpirationTime);
            model.addAttribute("message", "log4j.xml has been generated successfully!");
            return ResponseEntity.ok(new TimerResponse(remainingTime, (Map<String, Object>)log4JCache.get("log4j-config")));
        } catch (Exception e) {
            model.addAttribute("error", "Error generating log4j.xml: " + e.getMessage());
        }
        return ResponseEntity.ok(new TimerResponse(0, new HashMap<>()));
    }

    @PostMapping("/generate-log4j-xml")
    public ResponseEntity<FileSystemResource> generateLog4jXml() {

        Map<String, Object> data;
        Log4JCache log4JCache = Log4JCache.getInstance(TimeUnit.SECONDS, 0);
        Object obj = log4JCache.get("log4j-config");
        if(obj instanceof HashMap && ((Map<String, Object>)obj).size() > 0) {
            data = (Map<String, Object>) obj;
            File log4jXmlFile = new File("log4j2.xml");
            Template template;
            try {
                template = freemarkerConfig.createConfiguration().getTemplate("log4j_template.ftl");
                FileWriter writer = new FileWriter(log4jXmlFile);
                template.process(data, writer);
                writer.close();
            } catch (IOException | TemplateException e) {
                throw new RuntimeException(e);
            }

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + log4jXmlFile.getName())
                    .contentType(MediaType.APPLICATION_XML)
                    .contentLength(log4jXmlFile.length())
                    .body(new FileSystemResource(log4jXmlFile));

        } else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

}
