package com.lseg.ipps.solutions.tpl.model;

import java.util.HashMap;
import java.util.Map;

public class TimerResponse {

    private long remainingTime;

    Map<String, Object> data ;

    public TimerResponse(long remainingTime, Map<String, Object> data) {
        this.remainingTime = remainingTime;
        this.data = data;
    }


    public long getRemainingTime() {
        return remainingTime;
    }

    public void setRemainingTime(long remainingTime) {
        this.remainingTime = remainingTime;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }
}


