<script>
        let timerId;
        const userId = 'admin'; // Replace with actual user ID

        function updateTimer(remainingMs) {
            clearInterval(timerId);

            if (remainingMs <= 0) {
                $('#countdown').text('Timer: 00:00:00');
                return;
            }

            function displayTime() {
                const hours = Math.floor(remainingMs / 3600000);
                const minutes = Math.floor((remainingMs % 3600000) / 60000);
                const seconds = Math.floor((remainingMs % 60000) / 1000);

                $('#countdown').text(
                    `Timer: ${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
                );

                remainingMs -= 1000;

                if (remainingMs < 0) {
                    clearInterval(timerId);
                    $('#countdown').text('Timer: 00:00:00');
                }
            }

            displayTime();
            timerId = setInterval(displayTime, 1000);
        }

        // Check remaining time on page load
        $.get(`/get-remaining-time?userId=${userId}`, function(response) {
            updateTimer(response.remainingTime);
        });

        function usubmit() {
            const form = $('#configForm');
            const formData = new FormData(form[0]);

            // Add userId to the form data
            formData.append('userId', userId);

            $.ajax({
                url: form.attr('action'),
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    // Handle the log4j config generation response
                         displayLogInfo(response);

                    // Update the timer with the new remaining time
                    if (response.remainingTime !== undefined) {
                        updateTimer(response.remainingTime);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                    // Handle error appropriately
                }
            });

            // Prevent default form submission
            return false;
        }

        // Sync timer every minute
        setInterval(function() {
            $.get(`/get-remaining-time?userId=${userId}`, function(response) {
                updateTimer(response.remainingTime);
            });
        }, 60000);

        function displayLogInfo(logData) {
            const logEntries = $('#logEntries');
            logEntries.empty(); // Clear previous entries

            // Sort the keys to ensure consistent display order
            const logData1 = logData.data;
            const sortedKeys = Object.keys(logData1).sort();

            sortedKeys.forEach(key => {
                // Skip the remainingTime key as it's handled separately
                if (key === 'remainingTime') return;

                const value = logData1[key];
                const logEntry = $('<div>')
                    .addClass('log-entry')
                    .append(
                        $('<span>')
                            .addClass('log-key')
                            .text(formatKey(key))
                    )
                    .append(
                        $('<span>')
                            .addClass('log-value')
                            .text(formatValue(value))
                    );

                logEntries.append(logEntry);
            });
        }

</script>